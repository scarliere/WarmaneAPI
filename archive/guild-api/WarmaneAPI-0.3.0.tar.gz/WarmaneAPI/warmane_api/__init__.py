"""Public Warmane armory wrapper."""
