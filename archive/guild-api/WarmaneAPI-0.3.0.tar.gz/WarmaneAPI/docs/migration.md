# Moving to the dev device

## Package and transfer

Run `python scripts/package_repo.py` from any directory. Transfer the resulting `dist/WarmaneAPI-0.3.0.tar.gz` to the dev device and extract it. The archive includes application code, documentation, dependency pins, examples and offline test fixtures. It excludes `.venv`, caches, `.git`, agent/editor metadata, `.env` files and generated artifacts. `.env.example` is included.

Keep credentials and local environment configuration separate. No Warmane credentials are needed. Recreate the Python environment on the destination; copying an existing virtual environment across devices is unreliable.

## Install and run

Linux/macOS, from the extracted `WarmaneAPI` directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m pytest
uvicorn warmane_api.main:app --host 127.0.0.1 --port 8000 --workers 1
```

Windows PowerShell:

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest
.venv\Scripts\python -m uvicorn warmane_api.main:app --host 127.0.0.1 --port 8000 --workers 1
```

Python 3.12 is tested; package metadata supports 3.11+. Installing pinned dependencies requires PyPI access (or a separately prepared wheel cache). Start from the project root so `warmane_api` is importable; alternatively install the project with `python -m pip install --no-deps -e .` after dependencies.

Export any overrides from `.env.example` before starting. The server does not load `.env` automatically. The status/HTML cache lives in memory and starts empty after migration. No database or runtime state needs copying.

## Verify

Open `http://127.0.0.1:8000/health`, then `/docs`. Try the lightweight `/api/v1/characters/Icecrown/Sengtuary/status` first. The primary `/api/v1/characters/Icecrown/Sengtuary` route may need 40–60 seconds on a cold cache; set client/proxy timeouts above the configured lookup budget.

Use the exact realm name `Icecrown`. Unknown upstream resources can return an unexpected HTML page rather than a useful 404. For failed calls inspect the JSON error code, and for partial overviews inspect `meta.errors`.

## Optional container

```bash
docker build -t warmane-api:0.3.0 .
docker run --rm -p 127.0.0.1:8000:8000 --env-file .env.example warmane-api:0.3.0
```

The container runs as a non-root user and exposes a health check. Its single worker preserves the in-process request budget. Do not scale replicas/workers without a shared cache and limiter. Docker requires network access to fetch the base image and packages; availability of Docker on the target device must be checked there.

The native Python migration path was verified from the extracted archive in a fresh environment. The optional container could not be tested on the source machine because Docker socket access was denied.

## Repository layout

```text
warmane_api/          App, source client, parsers, aggregation, public models
tests/               Offline regressions and required fixtures
docs/                API contract, migration, secondary routes and provenance
examples/            JSON lookup command-line example
scripts/             Portable packaging and manual fixture capture
requirements*.txt    Tested dependency pins
pyproject.toml       Python package metadata and supported dependency ranges
Dockerfile           Optional container runtime
.env.example         Supported runtime settings
```

The supplied workspace did not have a functional Git repository. The migration archive is a source snapshot, not a Git-history backup. Initialize Git on the dev device if needed and commit the source there.
