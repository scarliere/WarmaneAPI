"""Create a portable source archive without local environments or captures."""
import argparse
from pathlib import Path
import tarfile


def main():
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=root / "dist/WarmaneAPI-0.3.0.tar.gz")
    output = parser.parse_args().output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    excluded = {".git", ".agents", ".codex", ".venv", "__pycache__", ".pytest_cache", "dist", "build", "htmlcov"}
    with tarfile.open(output, "w:gz") as archive:
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if path.is_symlink() or not path.is_file() or path == output:
                continue
            if any(p in excluded or p.endswith(".egg-info") for p in relative.parts):
                continue
            if path.name.startswith(".env") and path.name != ".env.example":
                continue
            if path.suffix in {".pyc", ".log"} or path.name in {".coverage", ".DS_Store", "Thumbs.db"}:
                continue
            archive.add(path, arcname=str(Path("WarmaneAPI") / relative), recursive=False)
    print(output)


if __name__ == "__main__":
    main()
