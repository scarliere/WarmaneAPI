# Warmane Character API

A read-only REST API for looking up a Warmane **character by name and realm**, with a complete overview and a lightweight online-status check. It reads the public armory; no Warmane account credentials are needed.

## Quick start

Python 3.11+ is required; Python 3.12 is the tested version. Run from the project directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-dev.txt
uvicorn warmane_api.main:app --host 127.0.0.1 --port 8000 --workers 1
```

On Windows, use `py -3.12 -m venv .venv` and `.venv\Scripts\Activate.ps1`. On Debian/Ubuntu, creating the environment may require the `python3-venv` package. Use `requirements.txt` instead of `requirements-dev.txt` for runtime dependencies only.

Open **http://127.0.0.1:8000/docs**. The root URL also opens the documentation. OpenAPI is at `/openapi.json` and liveness is at `/health`.

## Primary endpoints

| Method and path | Purpose |
| --- | --- |
| `GET /api/v1/characters/{realm}/{name}` | Combined character data, including the stat breakdown |
| `GET /api/v1/characters/{realm}/{name}/status` | Lightweight online-status polling with observation time |
| `GET /api/v1/characters/{realm}/{name}/summary` | Underlying JSON summary; `raw=true` preserves upstream fields/types |

Example: [Sengtuary on Icecrown](http://127.0.0.1:8000/api/v1/characters/Icecrown/Sengtuary).

```bash
curl --max-time 130 'http://127.0.0.1:8000/api/v1/characters/Icecrown/Sengtuary'
curl 'http://127.0.0.1:8000/api/v1/characters/Icecrown/Sengtuary/status'
```

The primary response groups data under:

```text
data.character       Identity, class, level, guild, achievement points
data.status          online, observed_at, cached, cache_ttl_seconds
data.stats           Attributes, Melee, Ranged, Defense, Spell, Resistances
data.equipment       Named items by slot, quality, enchant/gem codes
data.professions     primary and secondary skills
data.talent_builds   Detailed builds separated by spec
data.glyphs          Glyphs separated by spec
data.collections     Mounts and companions
data.reputation      Faction standings
data.achievements    Summary, categories, optional category data, recent activity
data.statistics      Summary, categories, optional category data
data.pvp             Summary, teams, full match history, optional match details
meta                 schema_version, completeness, sources, errors, omissions
```

`meta.schema_version` is `1.0`. The typed response schema is available in OpenAPI. See [the response contract](docs/api.md) for field details and partial results.

A cold overview usually takes **40–60 seconds** because its ten upstream sources are paced. Related fields share source pages; cached calls are faster. For regular online/offline checks, poll `/status`, not the full overview. `online: null` means unknown; an upstream failure is an error, not an offline status. `observed_at` is our retrieval time, not the character's last login.

## Optional deeper data

The primary route accepts:

| Parameter | Default | Range/purpose |
| --- | --- | --- |
| `include_categories` | `false` | Fetch each listed achievement/statistics category |
| `match_details_limit` | `0` | Fetch participant details for 0–100 unique matches |
| `match_details_offset` | `0` | Start at this offset in newest-first unique matches |
| `max_wait_seconds` | `120` | Overall lookup budget, 1–900 seconds |

Expansions can take several minutes. Full match history is included by default; participant detail expansion is opt-in. `meta.omitted` states the unrequested scope. Configure any reverse-proxy timeout above the lookup budget.

## Configuration and limits

Export environment variables before starting the server. [.env.example](.env.example) lists the supported settings; `.env` is **not automatically loaded**.

| Variable | Default |
| --- | --- |
| `WARMANE_CACHE_TTL_SECONDS` | `60` seconds for JSON/status |
| `WARMANE_HTML_CACHE_TTL_SECONDS` | `300` seconds for HTML/AJAX |
| `WARMANE_MIN_INTERVAL_SECONDS` | `4` seconds between upstream requests |
| `WARMANE_TIMEOUT_SECONDS` | `15` seconds per network operation |
| `CORS_ORIGINS` | Empty; comma-separated browser origins if needed |

The shared in-memory cache holds 256 source entries. One upstream request and one combined lookup can run at a time. Use **one worker/instance**; multiple processes do not share the limiter. The four-second interval is our policy, not a verified Warmane quota. Cached requests do not spend the upstream budget.

Standalone requests can return 503 while the budget is busy. Honor `Retry-After`; the combined lookup waits for routine pacing internally. Upstream 429 honors its retry header or uses a 60-second fallback. Unknown JSON API errors trigger a minimum 60-second cooldown without guessing the error code's meaning.

The service has no authentication or per-client admission limit. If making it publicly accessible, configure access control and request limits in your gateway. CORS is browser access configuration, not authentication.

## Development and migration

```bash
python -m pytest
python examples/character_lookup.py --name Sengtuary --realm Icecrown
python scripts/package_repo.py
```

The example prints the primary response as JSON; add `--status` for a lightweight check. Packaging creates `dist/WarmaneAPI-0.3.0.tar.gz`, excluding `.venv`, caches, secrets, editor/agent metadata and generated artifacts. Test fixtures and pinned dependency files are included. **Recreate the environment on the dev device; do not copy `.venv`.** See [migration instructions](docs/migration.md).

An optional [Dockerfile](Dockerfile) uses Python 3.12 and a non-root user. Keep one worker. Dependencies are pinned in `requirements.txt` and `requirements-dev.txt`; `pyproject.toml` records supported version ranges for package installations.

## Secondary routes and compatibility

Individual character sections and guild routes remain available; see [extended endpoints](docs/extended-api.md). The old `/full` route retains its previous `data.summary`-based response and is marked deprecated in OpenAPI; see [legacy combined response](docs/combined-lookup.md).

**Migration from 0.2:** the base character URL now returns the grouped overview instead of the upstream summary. Move old summary clients to `/summary` (including `?raw=true`), or update them to read `data.character` and `data.status`. Existing `/full` clients continue to work.

## Data quality and tests

Automated tests run offline using saved public responses and synthetic edge cases. Coverage includes Sengtuary/Icecrown, Cowysparttwo/Blackrock and Dojun/Icecrown. See [validation notes](docs/validation.md) and [research background](docs/research-findings.md).

HTML layout changes can cause parse errors. Successful sections are retained with `meta.complete: false` and named errors; null sections are not silently replaced with empty data. GearScore, authoritative last-online time, current location, guild notes/MOTD, raid-lockout expiration and reliable transmog mappings are not supplied. Enchant/gem codes remain the observed tooltip codes, not guessed item IDs or names.
